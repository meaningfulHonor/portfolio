package com.javateam.portfolio.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javateam.portfolio.domain.BoardDTO;
import com.javateam.portfolio.domain.CustomUser;
import com.javateam.portfolio.domain.MemberDTO;
import com.javateam.portfolio.domain.NoticeDTO;
import com.javateam.portfolio.domain.OrderPageItemDTO;
import com.javateam.portfolio.domain.ProductVO;
import com.javateam.portfolio.service.MemberService;
import com.javateam.portfolio.service.ProductService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/product")
@Slf4j
public class ProductController {

	@Autowired
	ProductService productService;
	
	@Autowired 
	MemberService memberService;
	
	@GetMapping("/itemPage.do")
	public String itemPage() {
		log.info("itemPage");
		
		return "/product/itemPage";
	}
		
	@GetMapping("/itemPage.do/{prdNum}")
	public String prdNumItemPage(@PathVariable("prdNum") int prdNum, Model model
				/*@RequestParam("select_quantity") int quantity*/) {
		// @PathVariable("id") String id,
		
		log.info("itemPage/" + prdNum + "의 페이지 입니다.");
		
		ProductVO productVO = productService.selectProduct(prdNum);
		log.info("productVO : ", productVO);
		model.addAttribute("product", productVO);
		
		String prdName = productVO.getPrdName();
		log.info("상품명 : {}", prdName);
		int prdPrice = productVO.getPrdPrice();
		log.info("가격 : {}", prdPrice);
		// log.info("수량 : {}", quantity);
		
		Object principal = SecurityContextHolder.getContext()
				.getAuthentication()
				.getPrincipal();
		
		CustomUser customUser = (CustomUser)principal;

		log.info("id : {}", customUser.getUsername());

		String id = customUser.getUsername(); 
		/*
		 * MemberDTO memberDTO = memberService.selectMember(id);
		 * log.info("memberDTO : ",memberDTO); model.addAttribute("member", memberDTO);
		 */
		
		OrderPageItemDTO orderPageItemDTO= new OrderPageItemDTO();
		orderPageItemDTO.setId(id);
		orderPageItemDTO.setPrdName(prdName);
		orderPageItemDTO.setPrdNum(prdNum);
		orderPageItemDTO.setPrdPrice(prdPrice);
		// orderPageItemDTO.setPrdQuantity(quantity);
		model.addAttribute("orderPageItemDTO", orderPageItemDTO);
		log.info("orderDTO : " +  new OrderPageItemDTO());
		
		return "/product/itemPage";
	}

}
